//
//  main.swift
//  DZ3
//
//  Created by Юлия Андреева on 04.07.2020.
//  Copyright © 2020 IULIIA ANDREEVA. All rights reserved.
//

import Foundation
import Cocoa

// 1. Описать несколько структур – любой легковой автомобиль и любой грузовик.

// 2. Структуры должны содержать марку авто, год выпуска, объем багажника/кузова, запущен ли двигатель, открыты ли окна, заполненный объем багажника.

// 3. Описать перечисление с возможными действиями с автомобилем: запустить/заглушить двигатель, открыть/закрыть окна, погрузить/выгрузить из кузова/багажника груз определенного объема.

// 4. Добавить в структуры метод с одним аргументом типа перечисления, который будет менять свойства структуры в зависимости от действия.

// 5. Инициализировать несколько экземпляров структур. Применить к ним различные действия.

// 6. Вывести значения свойств экземпляров в консоль.


    
  enum ModelName: String {
       case car = "KIA"
       case truck = "BMW"
   
   }
   enum engineState: String {
       case drive, stop
      }
   enum windowState: String {
          case open, close
         }
    enum trunkState: String {
             case full, empty
            }
  
   struct Car {
       var model: String
 
       let year: Int
       var trunkVolume: Int
       var engine: Bool
       var window: Bool
       var trunk: Int
       var cargo: Int
       var model1 = Car (model: " KIA ", year: 2010, trunkVolume: 3000, engineState:  "drive", windowState: open, trunkState: 1000, cargo: 50)
       
       struct Truck {
       var model: String
       let year: Int
       var trunkVolume: Int
       var engine: Bool
       var window: Bool
       var trunk: Int
       var cargo: Int
       var model2 = Truck (model : " BMW ", year: 2020, trunkVolume: 5000, engineState: "stop" , windowState: "close", trunkState: 3000, cargo: 100)
           
       init(model: String, year: Int, trunkVolume: Int, engine: Bool, window: Bool, trunk: Int, cargo: Int, model1: String, model2: String)  {
           
       self.model = model
       self.year = year
       self.trunkVolume = trunkVolume
       self.engine = engine
       self.window = window
       self.trunk = trunk
       self.cargo = cargo
   
           }
  
       func driveEngineState () {
   print("Hello I'm driving! \(model)")
   }
       func stopStationEngineState() {
   print("See you again, turn off the engine! \(model)")
   }
       func openWindowState() {
   print("Windows are open! \(model)")
   }
       func closeWindowState() {
   print("Windows are closed! \(model)")
   }
       func fullTrunkState () {
   print("20 kg load loaded in trunk! \(model)")
       }
       func emptyTrunkState () {
   print("50 kg cargo unloaded from the trunk! \(model)")
   }
   
    mutating func addLoad (_ cargo: Int) {
      trunk = trunk + cargo
   
       }
   }
}

  print ("Модель легкового автомобиля - \(KIA)")
  print ("Модель грузового автомобиля -  \(BMW)")
      
